<?php
include 'conn.php';

$name=$_POST['Name'];
$email=$_POST['Email'];
$password=$_POST['Password'];
$number=$_POST['Number'];
$gender=$_POST['gender'];
$img = $_FILES['image']['name'];
$img_type = $_FILES['image']['type'];
$img_name = $_FILES['image']['tmp_name'];
if($img_type=="image/jpeg"|| $img_type=="image/png"){
    move_uploaded_file($img_name,"image/$img");
}
$query="insert into info(name,email,password,number,image,gender) values('$name','$email','$password','$number','$img','$gender')";

$sql=mysqli_query($conn,$query);
if($sql){
    header('location:role.php');
}
    else{
        echo'unsucessfully';
    }









?>