<?php
$id=$_GET['id'];
include 'conn.php';

$sql="delete from info where id=$id";

$del = mysqli_query($conn,$sql);
if($del){
    header('location:role.php');
}
?>