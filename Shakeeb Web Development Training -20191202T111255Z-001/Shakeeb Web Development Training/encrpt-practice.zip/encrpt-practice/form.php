<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Login form</title>
    <style>
        h1{
            color: aliceblue;
            
        }
        label{
            
            font-style:italic;
            color: aliceblue;
            
        }
        input{
            
            margin: 3px;
            
        }
        form{
            
            width: 500px;
            height: 550PX;
       //background: #72c0d8;
            margin: 0 auto;
            
    }
        input[type=text]{
            
            width: 300px;
            height: 20px;
            border-radius: 30px;
        }
         input[type=Email]{
            
            width: 300px;
            height: 20px;
            border-radius: 30px;
        }
         input[type=password]{
            
            width: 300px;
            height: 20px;
            border-radius: 30px;
        }
    
        button{
            border-radius: 20px;
            background: #06c179;
            border: none;
            width:70px;
            height: 25px;
            //align-content: center;
            
        }
        
        .mybutton{
           position: relative;
            left:120px;
        }
        button:hover{
            background: #f2bcbc;
        transition:1s ease-in-out;
            cursor: pointer;
            
        }
        body{
      
        background: radial-gradient(#8512af,#000000);
        background-attachment: fixed;
        background-repeat: no-repeat;
           
        }
    </style>

</head>
<body>
  
   
   <form action="data-insert.php" method ="post" enctype="multipart/form-data">
      <h1 align=center>CREATE NEW FORM</h1>
      <label>Name:</label>
       <input type="text" name="Name" ><br><br>
         <label>Email:</label>
        <input type="email" name="Email" required><br><br>
          <label>Password:</label>
         <input type="password" name="Password" required><br><br>
           <label>Number:</label>
         <input type="text" name="Number"  required><br><br>
         <select name="gender">
         
          <option value="Male">Male</option>
           <option value="Female">Female</option>
           
           
           
           
        
           
  </select><br>
         <input type="file" name="image" required><br><br>
        <button type="submit">Insert</button> 
       <img src="image/<?php echo $image?>" alt="" width="300px" height="200px">
      
   </form>
    

    

    
</body>

</html>