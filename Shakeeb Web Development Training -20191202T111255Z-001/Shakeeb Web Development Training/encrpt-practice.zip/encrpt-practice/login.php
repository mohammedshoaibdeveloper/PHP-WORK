
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>lOgin Form</title>
    <style>
        body{
            
             background: linear-gradient(to right, #bdc3c7, #2c3e50);
        }
        form{
            height: 300px;
            width: 450px;
            background-color: #152121;
            margin: 0px auto;
            border-radius: 25px;
            margin-top: 150px;
            
            
        }
        h1{
            
            color: white;
            text-align: center;
            font-family:sans-serif;
        
            
        
         
            
        }
        input{
            
            
            height: 33px;
            width: 400px;
            border-radius: 10px;
            border: none;
            position: absolute;
            margin-left: 20px;
            margin-top: 10px;
        }
        button{
            width: 120px;
            height: 40px;
            background-color: aqua;
            border-radius: 20px;
            border: none;
            position: absolute;
            margin-left: 140px;
        }
        div{
            width: 450px;
            background-color: white;
            height: 2px;
            position: absolute;
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <form action="" method="post" enctype="multipart/form-data">
        
        <h1>TELEPHONE DIRECTORY</h1>
        <div>
            
        </div>
        <input type="text" name="name" required Placeholder=" Enter user-namee"><br><br><br>
         <input type="text" name="password" required Placeholder=" Enter password"><br><br><br>
         
        <button type="submit" name="submit">login</button>
          
    </form>
</body>
</html>
<?php
session_start();
include 'conn.php';
if(isset($_POST['submit'])){
    $user=$_POST['name'];
    $pwd=$_POST['password'];
    $md=mysqli_real_escape_string($conn,md5($pwd));
   $sql="SELECT * FROM users WHERE username='$user' AND password='$md'";
    echo $sql;
$query= mysqli_query($conn,$sql);
if(mysqli_num_rows($query)>0){
    while($row=mysqli_fetch_array($query)){
        
        $_SESSION['id']=$row['uid'];
       $_SESSION['username']=$row['username'];
       $_SESSION['role']=$row['role'];
        
    }
    header('location:role.php');
}
else{
    echo " password is not correct";
}
}

?>
