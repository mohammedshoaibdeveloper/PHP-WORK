<?php
include 'conn.php';
session_start();

if($_SESSION['id']==null){
    header('location:login.php');
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <table border=1px>
        <tr>
            <td>ID</td>
            <td>NAME</td>
            <td>EMAIL</td>
            <td>PASSWORD</td>
            <td>NUMBER</td>
            <td>GENDER</td>
            <td>IMAGE</td>
            
            <td>REGISTER</td>
            <td>Search</td>
            <td>DELETE</td>
            <td>Update</td>
            <td>Insert</td>
        </tr>
        
        <?php
        include 'conn.php';
        $query="select * from info";
        $sql=mysqli_query($conn,$query);
        if(mysqli_num_rows($sql)>0){
            while($row=mysqli_fetch_array($sql)){
                $id=$row['id'];
                $name=$row['name'];
                $email=$row['email'];
                $password=$row['password'];
                $number=$row['number'];
                $gender=$row['gender'];
                $image=$row['image'];
      
        
        ?>
        
        <tr>
            <td><?php echo $id;?></td>
            <td><?php echo $name;?></td>
            <td> <?php echo $email;?></td>
            <td> <?php echo $password;?></td>
        <td> <?php echo $number;?></td>
         
            <td> <?php echo $gender;?></td>
            <td>  <?php echo $image;?></td>
            <?php
            
        if($_SESSION['role']=="admin") {
          
               echo '<td><a href="account.php">Register</a></td>';
            echo '<td><a href="search.php">Search</a></td>';
         
             echo  "<td><a href='delete.php?id=$row[id]'>Delete</a></td>";
             echo  "<td><a href='update.php?id=$row[id]'>Update</a></td>";
        
             echo '<td><a href="form.php">INSERT</a></td>';
        
            

            }
               
        if($_SESSION['role']=="publisher") {
          
              echo '<td><a href="#">Register</a></td>';
               echo '<td><a href="search.php">Search</a></td>';
            
            echo '<td><a href="#">DELETE</a></td>';
            
             echo  "<td><a href='#'>Update</a></td>";
        
          echo '<td><a href="form.php">INSERT</a></td>';
            
            
            }
                 
            
            ?>
        </tr>
        <?php
            }
        }
        ?>
    </table>
</body>
</html>