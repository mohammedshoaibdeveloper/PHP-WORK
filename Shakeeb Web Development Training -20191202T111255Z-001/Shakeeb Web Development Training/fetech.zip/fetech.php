    <style>
table {
  border-collapse: collapse;
  width: 100%;
}

tr, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

tr:hover {background-color:#f5f5f5;}
</style>

<?php

$host="localhost";
$user="root";
$password="";
$dbname="student";
$conn=mysqli_connect($host,$user,$password,$dbname);
$query="select * from info";
$sql=mysqli_query($conn,$query);

    ?>
    <table>
        <tr>
            <td>id</td>
            <td>name</td>
            <td>email</td>
            <td>password</td>
            <td>number</td>
            </tr>
    <?php
if(mysqli_num_rows($sql)>0){
    while($row=mysqli_fetch_array($sql)){
        $id=$row['id'];
         $name=$row['name'];
         $email=$row['email'];
         $password=$row['password'];
         $number=$row['number'];
  


?>





    
     
        <tr>
        <td><?php echo $id ?></td>
        <td><?php echo $name ?></td>
         <td><?php echo $email ?></td>
         <td><?php echo $password ?></td>
        <td><?php  echo $number ?></td>
        </tr>

 




<?php

    }}

?>
</table>
