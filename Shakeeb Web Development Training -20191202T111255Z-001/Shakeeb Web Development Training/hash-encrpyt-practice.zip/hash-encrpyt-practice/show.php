<?php
include 'conn.php';
session_start();
if(!$_SESSION['id']){
    header('location:login.php');
}
else{
    echo $_SESSION['id'];
}




?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <table border="1px">
        <tr>
    <td>id</td>
    <td>name</td>
    <td>email</td>
    <td>password</td> 
    <td>gender</td>
    <td>number</td>
    <td>image</td>
   
        
        
        
    </tr>
       <?php
        include 'conn.php';
        $query='select * from info';
        $sql=mysqli_query($conn,$query);
        if(mysqli_num_rows($sql)>0){
            
            while($row=mysqli_fetch_array($sql)){
                
                
                $id=$row['id'];
                 $name=$row['name'];
                 $email=$row['email'];
                $password=$row['password'];
                 $gender=$row['gender'];
                 $number=$row['number'];
                 $image=$row['image'];
        
        ?>
        <tr>
            <td><?Php echo $id;  ?></td>
             <td><?Php echo $name;  ?></td>
              <td><?Php echo $email;  ?></td>
              <td><?Php echo $password;  ?></td>
               <td><?Php echo $gender;  ?></td>
                <td><?Php echo $number;  ?></td>
                    <td><?Php echo $image;  ?></td>
                               

                          

            
            
        </tr>
        
        
        ?>
        <?php
        
            }
        }
        
        ?>
        
    </table>
    <a href="logout.php">logout</a>
</body>
</html>