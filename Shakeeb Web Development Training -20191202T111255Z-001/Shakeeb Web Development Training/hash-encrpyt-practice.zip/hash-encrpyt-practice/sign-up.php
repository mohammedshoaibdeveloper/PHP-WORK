
<?php

include 'conn.php';

$name=$_POST['Name'];
$password=$_POST['Password'];
$role=$_POST['role'];
$hash=password_hash($password,PASSWORD_DEFAULT);
$query="insert into users (username,password,role) values('$name','$hash','$role')";
$sql=mysqli_query($conn,$query);
if($sql){
    header('location:login.php');
}



?>
