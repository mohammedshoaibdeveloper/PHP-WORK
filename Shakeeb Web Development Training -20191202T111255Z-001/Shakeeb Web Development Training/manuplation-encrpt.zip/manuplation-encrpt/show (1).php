<?php
include 'conn.php';
session_start();

if(!$_SESSION['id']){
    header('location:index.php');
}
echo $_SESSION['id'];

?>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

tr, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

tr:hover {background-color:#f5f5f5;}
</style>
<?php
$localhost="localhost";
$user="root";
$pass="";
$dbname="student";
$conn = mysqli_connect($localhost,$user,$pass,$dbname);
$sql="SELECT * FROM information";
$result = mysqli_query($conn,$sql);

   
?>
<table>
    <tr>
        <td>Id</td>
        <td>Name</td>
        <td>Email</td>
        <td>Age</td>
        <td>Contact</td>
        <td>Gender</td>
        <td>Image</td>
    </tr>
  <!--  <tr>
        <?php
       //echo" <td> {$rows['id']}</td> <td>{$rows['fullname']} </td>";
   
   //} 
//}
       ?>
    </tr> -->
    <?php
    include 'conn.php';
    if(mysqli_num_rows($result)>0){
   while($rows=mysqli_fetch_array($result)){
    //  echo $rows['id'] ."<br>" . $rows['fullname'];
  $id = $rows['id'];
  $name = $rows['fullname'];
  $email = $rows['email'];
  $age = $rows['age'];
  $contact = $rows['contact'];
  $gender = $rows['gender'];
  $image = $rows['image'];
    ?>
    <tr>
    <td><?php echo $id; ?></td> 
    <td><?php echo $name; ?></td> 
    <td><?php echo $email; ?></td> 
    <td><?php echo $age; ?></td> 
    <td><?php echo $contact; ?></td> 
    <td><?php echo $gender; ?></td> 
    <td><?php echo $image; ?></td> 
    </tr>
    <?php }} ?>
</table>
<a href="logout.php">logout</a>