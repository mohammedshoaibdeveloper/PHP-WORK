<?php
$host="localhost";
$user="root";
$password="";
$dbname="student";
$conn=mysqli_connect($host,$user,$password,$dbname);



?>
