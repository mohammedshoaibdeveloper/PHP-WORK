<?php
include'conn.php';



?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
        body{
             background: linear-gradient(to right, #ffefba, #ffffff);
        }
    marquee{
   font-family: monospace;
        font-size: 30px;
    
    
    }  
    
    </style>
</head>
<body>
   <?php
    $query="select * from marquee";
    $sql=mysqli_query($conn,$query);
    if(mysqli_num_rows($sql)>0){
        while($row=mysqli_fetch_array($sql)){
            $text=$row['text'];

        }}
    
    
    ?>
    <marquee><?php echo $text; ?></marquee>
   
</body>
</html>