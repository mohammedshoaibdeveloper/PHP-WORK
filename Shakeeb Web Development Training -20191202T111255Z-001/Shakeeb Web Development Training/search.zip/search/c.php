<style>
        h1{
            color: aliceblue;
            
        }
        label{
            
            font-style:italic;
            color: aliceblue;
            
        }
        input{
            
            margin: 3px;
            
        }
        form{
            
            width: 500px;
            height: 550PX;
       //background: #72c0d8;
            margin: 0 auto;
            
    }
        input[type=text]{
            
            width: 300px;
            height: 20px;
            border-radius: 30px;
        }
         input[type=Email]{
            
            width: 300px;
            height: 20px;
            border-radius: 30px;
        }
         input[type=password]{
            
            width: 300px;
            height: 20px;
            border-radius: 30px;
        }
    
        button{
            border-radius: 20px;
            background: #06c179;
            border: none;
            width:70px;
            height: 25px;
            //align-content: center;
            
        }
        
        .mybutton{
           position: relative;
            left:120px;
        }
        button:hover{
            background: #f2bcbc;
        transition:1s ease-in-out;
            cursor: pointer;
            
        }
        body{
      
/*
        background: radial-gradient(#8512af,#000000);
        background-attachment: fixed;
        background-repeat: no-repeat;
*/
           
        }
    </style>


<?php
include'conn.php';

        
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form>
          <h1 align=center>CREATE NEW FORM</h1>
          <input type="text" name="fullname" placeholder="Enter Full Name" value="<?php echo $name; ?>" ><br>
        <input type="email" name="email" placeholder="Enter Email" value="<?php echo $email; ?>"required><br>
      <input type="text" name="password" placeholder="Enter password" value="<?php echo $password; ?>" ><br>
      <input type="text" name="contact" placeholder="Enter Contact" value="<?php echo $number; ?>" ><br>
       <select name="gender">
         <?php 
          /* if($gender=="Male"){
           ?>
           <option value="Male">Male</option>
           <option value="Female">Female</option>
     
       <?php }
          else{ ?>
           <option value="Female">Female</option>
            <option value="Male">Male</option>
           <?php } */ 
           if($gender=="male"){
               echo '<option value="Male">Male</option>
           <option value="Female">Female</option>';
           }
           else{
               echo '<option value="Female">Female</option> <option value="Male">Male</option>
           ';
           }                   
           
           ?>
           
           
           
        
           
  </select><br>
       <input type="file" name="image" >
     <input type="submit" name="submit" value="update">
  <img src="image/<?php echo $image; ?>" width="100px" height="100px">
    
    </form>


</body>
</html>
    <?php

if(isset($_POST['submit'])){
    
     $id=$_POST['id'];
    
      $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];

    $contact=$_POST['number'];
    $gender=$_POST['gender'];
$u="update info set name='$name',email='$email',password='$password',contact='$contact',gender='$gender' where id='$id'";
    
    $data=mysqli_query($conn,$u);
    if($data){
        echo "sucessfully";
    }
    else{
        echo "unsucessfully";
    }
}



?>


