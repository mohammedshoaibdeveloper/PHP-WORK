<?php
include 'conn.php';
$query='select * from info';
$sql=mysqli_query($conn,$query);
if(mysqli_num_rows($sql)>0){
    
    while($row=mysqli_fetch_assoc($sql)){
        $id=$row['id'];
        $name=$row['name'];
        $email=$row['email'];
        $password=$row['password'];
        $number=$row['number'];
        $gender=$row['gender'];
        $image=$row['image'];
        
          
        
    }
}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Login form</title>
    <style>
        h1{
            color: aliceblue;
            
        }
        label{
            
            font-style:italic;
            color: aliceblue;
            
        }
        input{
            
            margin: 3px;
            
        }
        form{
            
            width: 500px;
            height: 550PX;
       //background: #72c0d8;
            margin: 0 auto;
            
    }
        input[type=text]{
            
            width: 300px;
            height: 20px;
            border-radius: 30px;
        }
         input[type=Email]{
            
            width: 300px;
            height: 20px;
            border-radius: 30px;
        }
         input[type=password]{
            
            width: 300px;
            height: 20px;
            border-radius: 30px;
        }
    
        button{
            border-radius: 20px;
            background: #06c179;
            border: none;
            width:70px;
            height: 25px;
            //align-content: center;
            
        }
        
        .mybutton{
           position: relative;
            left:120px;
        }
        button:hover{
            background: #f2bcbc;
        transition:1s ease-in-out;
            cursor: pointer;
            
        }
        body{
      
        background: radial-gradient(#8512af,#000000);
        background-attachment: fixed;
        background-repeat: no-repeat;
           
        }
    </style>

</head>
<body>
  
   
   <form action="form.php?id=<?php echo $id?>" method ="post" enctype="multipart/form-data">
      <h1 align=center>CREATE NEW FORM</h1>
      <label>Name:</label>
       <input type="text" name="Name" value="<?php echo $name ?>"><br><br>
         <label>Email:</label>
        <input type="email" name="Email"  value="<?php echo $email ?>" required><br><br>
          <label>Password:</label>
         <input type="password" name="Password"  value="<?php echo $password ?>"required><br><br>
           <label>Number:</label>
         <input type="text" name="Number"  value="<?php echo $number ?>"required><br><br>
         <select name="gender">
         <?php 
          /* if($gender=="Male"){
           ?>
           <option value="Male">Male</option>
           <option value="Female">Female</option>
     
       <?php }
          else{ ?>
           <option value="Female">Female</option>
            <option value="Male">Male</option>
           <?php } */ 
           if($gender=="male"){
               echo '<option value="Male">Male</option>
           <option value="Female">Female</option>';
           }
           else{
               echo '<option value="Female">Female</option> <option value="Male">Male</option>';
           }                   
           
           ?>
           
           
           
        
           
  </select><br>
         <input type="file" name="image" required><br><br>
       <input type="submit" name="submit" value="Insert">  
       <img src="image/<?php echo $image?>" alt="" width="300px" height="200px">
      
   </form>
    

    

    
</body>

</html>

<?php
if(isset($_POST['submit'])){
include'conn.php';
  $id=$_GET['id'];
     $name=$_POST['Name'];
    $email=$_POST['Email'];
    $password=$_POST['password'];

    $contact=$_POST['Number'];
    $gender=$_POST['gender'];
//print_r($_FILES['image']);
//$sql;
$img = $_FILES['image']['name'];
$img_type = $_FILES['image']['type'];
$img_name = $_FILES['image']['tmp_name'];
if($img_type=="image/jpeg"|| $img_type=="image/png"){
    move_uploaded_file($img_name,"image/$img");
}
    if($img==null){
        $sql="UPDATE info set name='$name', email='$email', password='$password', number='$contact', gender='$gender' where id=$id";
    }
    else{
        $sql="UPDATE info set name='$name', email='$email', number='$contact', gender='$gender', image='$img' where id=$id";
    }
//echo $sql;
    
    if(mysqli_query($conn,$sql)){
        header('location:select.php');
    }
  
   
}


?>










