<?php
include 'conn.php';


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
    
        table{
            
            margin-top: 100px;
        }
    </style>
</head>
<body>
    <form action="" method="get">
    <input type="text" name="id" placeholder="Enter your id">    
    <input type="submit" value="search">   
       <table  border="1" cellpadding="7">
           <tr>
               <th>NAME</th>
               <th>EMAIL</th>
               <th>PASSWORD</th>
               <th>NUMBER</th>
               <th>IMAGE</th>
                <th>GENDER</th>
                    
           </tr>
           
           <?php
          if(isset($_GET['id'])){
              
              $id=$_GET['id'];
              $query=mysqli_query($conn,"select * from info where id=$id");
              while($result=mysqli_fetch_array($query))
              {
                     $image=$result['image'];
                ?>
                  <tr>
                     
                      <th><?php echo $result['name'];?></th>
                      <th><?php echo $result['email'];?></th>
                      <th><?php echo $result['password'];?></th>
                      <th><?php echo $result['number'];?></th>
                      <td><img src="image/<?php echo $image; ?>" width="100px" height="100px"></td>
                      <th><?php echo $result['gender'];?></th>
<!--                  
                </tr>
                  <?php
              }
          }
           ?>
         
       </table>
        
        
    </form>
</body>
</html>