<?php
include'conn.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>
  <table id="customers">
  <tr>
    <th>ID</th>
    <th>NAME</th>
    <th>EMAIL</th>
    <th>PASSWORD</th>
    <th>NUMBER</th>
     <th>IMAGE</th>
         <th>gender</th>
       <th>delete</th>
         <th>update</th>
         <th>search</th>
  </tr>
  <?php
      $sql="select * from info";
      $query=mysqli_query($conn,$sql);
      if(mysqli_num_rows($query)>0){
          while($row=mysqli_fetch_assoc($query)){
              $id=$row['id'];
              $name=$row['name'];
              $email=$row['email'];
              $password=$row['password'];
               $number=$row['number'];
               $image=$row['image'];
               $gender=$row['gender'];
          
      
      ?>
  <tr>
    <td><?php echo $id; ?></td>
    <td><?php echo $name; ?></td>
    <td><?php echo $email; ?></td>
    <td><?php echo $password; ?></td>
    <td><?php echo $number; ?></td>
    <td><img src="image/<?php echo $image; ?>" width="100px" height="100px"></td>
        <td><?php echo $gender; ?></td>
    <td><a href="delete.php?id=<?php echo $id; ?>">Delete</a></td>
      <td><a href="form.php?id=<?php echo $id; ?>">update</a></td>
      <td><a href="search.php">search</a></td>
     
  
   
  </tr>
  <?php }}?>
  
</table>
</body>
</html>