<?php

$host="localhost";
$user="root";
$pwd="";
$dbname="student";
$conn = mysqli_connect($host,$user,$pwd,$dbname);

?>