<?php
$id=$_GET['id'];
$host="localhost";
$user="root";
$pwd="";
$dbname="student";
$conn = mysqli_connect($host,$user,$pwd,$dbname);
$sql="delete from info where id=$id";

$del = mysqli_query($conn,$sql);
if($del){
    header('location:select.php');
}
?>