<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> styling</title>
    
    <style>
       
        h1{
            border: 8px dashed;
            border-color:antiquewhite;
            width: 350px;
            height: 165px;
            position: relative;
            margin: 0 auto;
            top: 220px;
            color: aliceblue;
            text-align: center;
            font-family: monospace;
            font-size: 40PX;
        }
        body{
            
            
             background: linear-gradient(to right, #eecda3, #ef629f);
            background-attachment: fixed;
            background-repeat: no-repeat;
        }
    </style>
    
</head>
<body>
    
    
    <h1><br>SHAKEEB ANWAR</h1>
</body>
</html>