<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MY WEBSITE</title>
    <style>
        @import url('https://fonts.googleapis.com/css?family=Montserrat&display=swap');
        

        body{
            
          background: linear-gradient(to right, #f2709c, #ff9472);
            background-repeat: no-repeat;
            background-attachment: fixed;
            
        }
        div{
            color: #f0f5f8;
            margin: 0 auto;
            width: 500px;
            font-size: 25 px;
            padding-top: 20 px;
            text-align: center;
            border: 8px dashed #fff;
            position: relative;
            top: 200px;
            line-height: 3;
            font-family: 'Montserrat', sans-serif;
            
            
        }
        
    
    </style>
</head>
<body>
    <header>
       <div>
        <h1>MOHAMMED SHOAIB</h1>
        </div>
        
        
    </header>
</body>
</html>