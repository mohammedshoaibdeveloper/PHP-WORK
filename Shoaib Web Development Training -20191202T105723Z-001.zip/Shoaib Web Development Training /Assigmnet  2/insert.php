<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Form</title>
    <style>
        body{
            background: linear-gradient(to right, #bdc3c7, #2c3e50);
            background-attachment: fixed;
            background-repeat: no-repeat;
            }
       
        form{
            height: 300px;
            width: 450px;
            background-color: #152121;
            margin: 0px auto;
            border-radius: 25px;
            margin-top: 150px;
        }
        h1{
            color: white;
            text-align: center;
            font-family: sans-serif;
        }
        input{
            height: 33px;
            width: 400px;
/*            border-radius: 10px;*/
            border: none;
            position: absolute;
            margin-left: 20px;
            margin-top: 10px;
        }
        button{
            width:  120px;
            height: 40px;
            background: linear-gradient(to right, #bdc3c7, #2c3e50);
            border-radius: 20px;
            border: none;
            position: absolute;
            margin-left: 140px;
                
        }
        button:hover{
            background: linear-gradient(to right, #ffd89b, #19547b);
            transition: 1s ease-in-out;
            cursor: pointer;
            
        }
        div{
            width: 450px;
            background-color: white;
            height: 2px;
            position: absolute;
            margin-bottom: 8px;
        }

    
    
    
    </style>
</head>
<body>
   <form action="insertconn.php" method="post" enctype="multipart/form-data">
      <h1>TELEPHONE DIRECTORY</h1>
      <div>
          </div>
      
      <input type="text" name="fullname" placeholder="Enter Full name" required><br><br><br>
      <input type="text" name="contact" placeholder="Enter Contact no" required><br><br><br>
      <input type="email" name="email" placeholder="Enter Email" required><br><br><br><br>
      <button type="submit">Insert</button>
       
       </form>
    
</body>
</html>