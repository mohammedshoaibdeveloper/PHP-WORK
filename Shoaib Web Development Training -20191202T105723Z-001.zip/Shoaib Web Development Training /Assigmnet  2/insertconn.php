<?php
$host="localhost";
$user="root";
$pwd="";
$dbname="assigment2";
$conn=mysqli_connect($host,$user,$pwd,$dbname);
if($conn){
    echo "Successfully";
    }
else{
    echo "Connection Failed";
}
     $name=$_POST['fullname'];
     $contact=$_POST['contact'];
     $email=$_POST['email'];
$sql="INSERT INTO assigment(fullname,contact,email) VALUES ('$name','$contact','$email')";
if(mysqli_query($conn,$sql)){
    header('location:insert.php');
}
?>