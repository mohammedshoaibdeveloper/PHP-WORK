<?php
$localhost="localhost";
$user="root";
$pwd="";
$dbname="assigment2";
$conn=mysqli_connect("$localhost","$user","$pwd","$dbname");
$sql="SELECT * FROM assigment";
$result=mysqli_query($conn,$sql);
?>
<?php
if(mysqli_num_rows($result)>0){
    while($rows=mysqli_fetch_array($result)){
        $ID=$rows["ID"];
        $fullname=$rows["fullname"];
        $contact=$rows["contact"];
        $email=$rows["email"];
        ?>
        <tr>
            <td><?php echo $ID; ?></td>
            <td><?php echo $fullname; ?></td>
            <td><?php echo $contact; ?></td>
            <td><?php echo $email; ?></td>
            
            
            
            
        </tr>
<?php  }}  ?>
