<style>

    table{
        border-collapse: collapse;
        width: 100%;
    }
    tr,td{
        color:chartreuse;
        text-align: left;
        border-bottom: 1px solid #ddd;
        padding: 8px;
        
    }
    tr:hover{background-color: #f6fcfa;}
    body{
        background: linear-gradient(to right, #085078, #85d8ce);
         background-attachment: fixed;
         background-repeat: no-repeat;
    }
    table{
        color:brown;
    }


</style>




<?php
$localhost="localhost";
$user="root";
$pwd="";
$dbname="assigment2";
$conn=mysqli_connect("$localhost","$user","$pwd","$dbname");
$sql="SELECT * FROM assigment";
$result=mysqli_query($conn,$sql);
?>
<table>
    <tr>
        <td>ID</td>
         <td>Full Name</td>
          <td>Contact</td>
         <td>Email</td>
        
</tr>
   <body>
    <?php
if(mysqli_num_rows($result)>0){
    while($rows=mysqli_fetch_array($result)){
        $ID=$rows["ID"];
        $fullname=$rows["fullname"];
        $contact=$rows["contact"];
        $email=$rows["email"];
        ?>
         <tr>
            <td><?php echo $ID; ?></td>
            <td><?php echo $fullname; ?></td>
            <td><?php echo $contact; ?></td>
            <td><?php echo $email; ?></td>
            
            
        </tr>
        
        
        <?php }} ?>
        </body>
    
</table>