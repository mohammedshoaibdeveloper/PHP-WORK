<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>WEBSITE</title>
    
</head>
<body>
    <header>
        <h1 align="center">BALOCHABAD</h1>
   <div align="center"> <pre><a href="https://www.google.com" >HOME</a>  <a href="https://www.google.com" >MOVIES</a>  <a href="https://www.google.com" >SONGS</a>  <a href="https://www.google.com" >ABOUT</a>  <a href="https://www.google.com" >CONTACT</a></pre></div>
   <img src="70390544_2362925297309344_7762499603303235584_n.jpg" alt="" width="1340px" height="300px">
   <h2>New Balochi Film "Balochabad is Ready for Release</h2></header>
   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur sit nisi, corporis aliquid eos magni alias perferendis, quidem fugit. Eaque officiis illo, omnis, odio dignissimos fugit commodi est mollitia amet.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur sit nisi, corporis aliquid eos magni alias perferendis, quidem fugit.</p>
   
   
   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur sit nisi, corporis aliquid eos magni alias perferendis, quidem fugit. Eaque officiis illo, omnis, odio dignissimos fugit commodi est mollitia amet.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur sit nisi, corporis aliquid eos magni alias perferendis, quidem fugit.</p>
   
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur sit nisi, corporis aliquid eos magni alias perferendis, quidem fugit. Eaque officiis illo, omnis, odio dignissimos fugit commodi est mollitia amet.Lorem ipndis, quidem fugit., quidem fugit. Eaque officiis illo, omnis, odio dignissimos fugit commodi est mollitia amet.Lorem ipsum dolor sit amet, consectetur adipisicing elit. A</p>
    
     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur sit nisi, corporis aliquid eos magni alias perferendis, quidem fugit. Eaque officiis illo, omnis, odio dignissimos fugit commodi est mollitia amet.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur sit nisi, corporis aliquid eos magni alias perferendis, quidem fugit.. Eaque officiis illo, omnis, odio dignissimos fugit commodi est mollitia amet.Lorem ipndis, quidem fugit., quidem fugit. </p>
     
      <p><b>Lorem ipsum dolo, omnis,orem ipsum dolor sitctetur adipisicing elit. Aspernatur sit nisi, corporis aliquid eos magni alias perferendis, quidem fugit.</b></p>
   
    
    
    
</body>
</html>