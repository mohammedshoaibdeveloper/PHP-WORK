<?php

$localhost="localhost";
$user="root";
$pass="";
$dbname="student";
$conn = mysqli_connect($localhost,$user,$pass,$dbname);

?>