<?php

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Navigation Form</title>
    <style>
        body {
            background: linear-gradient(to right, #12364e, #165ba0);
            background-attachment: fixed;
            background-repeat: no-repeat;
        }

        form {
            height: 300px;
            width: 450px;
            background-color: #152121;
            margin: 0px auto;
            border-radius: 25px;
            margin-top: 150px;
        }

        h1 {
            padding-top: 4px;
            margin: 4px;
            color: white;
            text-align: center;
            font-family: sans-serif;
        }

        input {
            height: 33px;
            width: 400px;
            /*            border-radius: 10px;*/
            border: none;
            position: absolute;
            margin-left: 20px;
            margin-top: 10px;
        }

        button {
            width: 120px;
            height: 40px;
            background: linear-gradient(to right, #bdc3c7, #2c3e50);
            border-radius: 20px;
            border: none;
            position: absolute;
            margin-left: 140px;

        }

        button:hover {
            background: linear-gradient(to right, #ffd89b, #19547b);
            transition: 1s ease-in-out;
            cursor: pointer;

        }

        div {
            width: 450px;
            background-color: white;
            height: 2px;
            position: absolute;
            margin-bottom: 8px;
        }

        registerlink {
            position: absolute;
            margin-left: 170px;



        }
    </style>
</head>

<body>
    <form action="" method="post" enctype="multipart/form-data">
        <h1>Create Navigation</h1>
        <div>
        </div>

        <input type="text" placeholder="Enter Button Name" name="button" required><br><br><br>
        <input type="text" placeholder="Enter Link here" name="link" required><br><br><br>

        <button type="submit" name="submit">create</button><br><br><br>
        <registerlink>
            

    </form>

</body>

</html>
<?php
include 'connection.php';


if(isset($_POST['submit'])){
    $button=$_POST['button'];
    $link=$_POST['link'];
  
 $sql="INSERT INTO navigation(button,link) VALUES('$button','$link')";
if(mysqli_query($conn,$sql)){
header('location:showdata.php');


}
    
    
    
}

?>
 
