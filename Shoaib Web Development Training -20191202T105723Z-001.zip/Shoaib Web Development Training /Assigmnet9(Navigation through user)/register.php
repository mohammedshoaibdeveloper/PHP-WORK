<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Register Form</title>
    <style>
        body {
            background: linear-gradient(to right, #59c173, #a17fe0, #5d26c1);
            background-attachment: fixed;
            background-repeat: no-repeat;
        }

        form {
            height: 300px;
            width: 450px;
            background-color: #152121;
            margin: 0px auto;
            border-radius: 25px;
            margin-top: 150px;
        }

        h1 {
            padding-top: 4px;
            margin: 4px;
            color: white;
            text-align: center;
            font-family: sans-serif;
        }

        input {
            height: 33px;
            width: 400px;
            /*            border-radius: 10px;*/
            border: none;
            position: absolute;
            margin-left: 20px;
            margin-top: 10px;
        }

        button {
            width: 120px;
            height: 40px;
            background: linear-gradient(to right, #bdc3c7, #2c3e50);
            border-radius: 20px;
            border: none;
            position: absolute;
            margin-left: 140px;

        }

        button:hover {
            background: linear-gradient(to right, #ffd89b, #19547b);
            transition: 1s ease-in-out;
            cursor: pointer;

        }

        div {
            width: 450px;
            background-color: white;
            height: 2px;
            position: absolute;
            margin-bottom: 8px;
        }

        select {
            position: absolute;
            margin-left: 20px;

        }
    </style>
</head>

<body>
    <form action="register.php" method="post" enctype="multipart/form-data">
        <h1>REGISTRATION</h1>
        <div>
        </div>

        <input type="text" placeholder="Enter Username" name="uname" required><br><br><br>
        <input type="password" placeholder="Enter Password" name="psw" required><br><br><br>
        <select name="role" id=""><br><br>
            <option value="admin">Admin</option>
            <option value="publisher">User</option>
        </select><br><br>
        <button type="submit" name="submit">Register</button>

    </form>

</body>

</html>
<?php
if(isset($_POST['submit'])){
include 'connection.php';

    
    $user=mysqli_real_escape_string($conn,$_POST['uname']);
    $pwd=mysqli_real_escape_string($conn,$_POST['psw']);
    $role=mysqli_real_escape_string($conn,$_POST['role']);
   
    
    $hash = password_hash($pwd, PASSWORD_DEFAULT);
   
$sql="insert into users(username,password,role) values('$user','$hash','$role')";
$query= mysqli_query($conn,$sql);
if($query){
   header('location:login.php');
}
}
?>