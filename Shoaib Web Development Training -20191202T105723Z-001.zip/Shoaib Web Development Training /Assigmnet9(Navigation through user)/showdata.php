<?php
include'connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
        #customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
         button {
             
           color: aliceblue;
            width: 300px;
            height: 40px;
            background: linear-gradient(to right, #013658, #0a4c8e);
            border-radius: 20px;
            border: none;
            position: absolute;
            margin-left: 500px;

        }
    </style>
</head>

<body>
 <form action="showdata.php" method="post" enctype="multipart/form-data">
  <button type="submit" name="submit" >Create Navigation Here</button><br><br><br>

    <table id="customers">
        <tr>
            <th>ID</th>
            <th>BUTTON NAME</th>
            <th>LINK</th>


        </tr>
        <?php
      $sql="select * from navigation";
      $query=mysqli_query($conn,$sql);
      if(mysqli_num_rows($query)>0){
          while($row=mysqli_fetch_assoc($query)){
              $id=$row['id'];
              $button=$row['button'];
              $link=$row['link'];
              
          
      
      ?>
        <tr>

            <td><?php echo $id; ?></td>
            <td><?php echo $button; ?></td>
            <td><?php echo $link; ?></td>







        </tr>
        <?php }}?>

    </table>
</body>

</html>
<?php
if(isset($_POST['submit'])){
   
    header('location:createnavigation.php');

}
 ?>
    