<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User</title>
    <link rel="stylesheet" href="styling.css">
</head>
<body>
  
 
  
              
            
               <nav>
               <ul>
                 <?php
     include 'connection.php';
     $sql="select * from navigation";
      $query=mysqli_query($conn,$sql);
      if(mysqli_num_rows($query)>0){
          while($row=mysqli_fetch_assoc($query)){
             $button=$row['button'];
             $link=$row['link'];
              
        
     ?>
                 <li><a href="<?php echo $link; ?>"><?php echo $button; ?></a></li>
               <?php }}?>
                </ul>
                </nav>
             
             
</body>
              
            
</html>
 
              