<?php session_start();
if(!$_SESSION['id']){
      header('location:loginform.php');
}
if($_SESSION['role']=="admin"){

}
if($_SESSION['role']=="user"){
}
?>
<?php
include'connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <style>
        #customers {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>

<body>
    <table id="customers">
        <tr>
            <th>ID</th>
            <th>NAME</th>
            <th>EMAIL</th>
            <th>AGE</th>
            <th>CONTACT</th>
            <th>gender</th>
            <th>IMAGE</th>
            <?php 
              
              if($_SESSION['role']=='admin'){
            echo '<th>INSERT</th>';
            echo '<th>UPDATE</th>';
            echo '<th>DELETE</th>';
            
                echo '<th>SEARCH</th>';
            
            echo '<th>LOGOUT</th>';
              }
            ?>

                <?php
            if($_SESSION['role']=='publisher'){
           echo '<th>UPDATE</th>';
            echo '<th>DELETE</th>';
                } 
            ?>
            


        </tr>
        <?php
      $sql="select * from information";
      $query=mysqli_query($conn,$sql);
      if(mysqli_num_rows($query)>0){
          while($row=mysqli_fetch_assoc($query)){
              $id=$row['id'];
              $name=$row['fullname'];
              $email=$row['email'];
              $age=$row['age'];
               $contact=$row['contact'];
              $gender=$row['gender']; 
              $image=$row['image'];
               
          
      
      ?>
        <tr>
           
            <td><?php echo $id; ?></td>
            <td><?php echo $name; ?></td>
            <td><?php echo $email; ?></td>
            <td><?php echo $age; ?></td>
            <td><?php echo $contact; ?></td>
            <td><?php echo $gender; ?></td>
            <td><img src="image/<?php echo $image; ?>" width="100px" height="100px"></td>
<?php 
              
              if($_SESSION['role']=='admin'){
            echo '<td><a href="insert.php">Insert</a></td>';
            echo '<td><a href="updateform.php?id=<?php echo $id; ?>">update</a></td>';
           echo '<td><a href="delete.php?id=<?php echo $id; ?>">Delete</a></td>';
            echo '<td><a href="search.php">search</a></td>';
            echo '<td><a href="logout.php">logout</a></td>';
            } 
            ?>
            <?php 
              
              if($_SESSION['role']=='publisher'){
           echo '<td><a href="updateform.php?id=<?php echo $id; ?>">update</a></td>';
            echo '<td><a href="delete.php?id=<?php echo $id; ?>">Delete</a></td>';
         } 
            ?>
            




        </tr>
        <?php }}?>

    </table>
</body>

</html>