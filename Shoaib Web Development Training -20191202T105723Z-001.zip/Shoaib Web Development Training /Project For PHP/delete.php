<?php
$id=$_GET['id'];
$host="localhost";
$user="root";
$pwd="";
$dbname="student";
$conn = mysqli_connect($host,$user,$pwd,$dbname);
$sql="delete from information where id=$id";

$del = mysqli_query($conn,$sql);
if($del){
    header('location:Allfunctions.php');
}
?>