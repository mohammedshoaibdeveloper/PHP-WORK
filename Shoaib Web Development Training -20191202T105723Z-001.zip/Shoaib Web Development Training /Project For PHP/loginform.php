<?php

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login Form</title>
    <style>
        body {
            background: linear-gradient(to right, #bdc3c7, #2c3e50);
            background-attachment: fixed;
            background-repeat: no-repeat;
        }

        form {
            height: 300px;
            width: 450px;
            background-color: #152121;
            margin: 0px auto;
            border-radius: 25px;
            margin-top: 150px;
        }

        h1 {
            color: white;
            text-align: center;
            font-family: sans-serif;
        }

        input {
            height: 33px;
            width: 400px;
            /*            border-radius: 10px;*/
            border: none;
            position: absolute;
            margin-left: 20px;
            margin-top: 10px;
        }

        button {
            width: 120px;
            height: 40px;
            background: linear-gradient(to right, #bdc3c7, #2c3e50);
            border-radius: 20px;
            border: none;
            position: absolute;
            margin-left: 140px;

        }

        button:hover {
            background: linear-gradient(to right, #ffd89b, #19547b);
            transition: 1s ease-in-out;
            cursor: pointer;

        }

        div {
            width: 450px;
            background-color: white;
            height: 2px;
            position: absolute;
            margin-bottom: 8px;
        }

        registerlink {
            position: absolute;
            margin-left: 170px;



        }
    </style>
</head>

<body>
    <form action="" method="post" enctype="multipart/form-data">
        <h1>TELEPHONE DIRECTORY</h1>
        <div>
        </div>

        <input type="text" placeholder="Enter Username" name="uname" required><br><br><br>
        <input type="password" placeholder="Enter Password" name="psw" required><br><br><br>

        <button type="submit" name="submit">Login</button><br><br><br>
        <registerlink>
            <a href="register.php" style="color:#ffffff">Register</a>
        </registerlink>

    </form>

</body>

</html>
<?php
session_start();
include 'connection.php';
if(isset($_POST['submit'])){
    $user=$_POST['uname'];
    $pwd=$_POST['psw'];
    
   $sql="SELECT * FROM users WHERE username='$user'";
$query= mysqli_query($conn,$sql);
if(mysqli_num_rows($query)>0){
    while($row=mysqli_fetch_array($query)){
       if(password_verify($pwd,$row['password'])){
            
        $_SESSION['id']=$row['uid'];
        $_SESSION['username']=$row['username'];
        $_SESSION['role']=$row['role'];
       }
        
    }
    header('location:Allfunctions.php');
}
else{
    echo " password is not correct";
}
}


?>