<?php
include 'connection.php';
session_start();

if($_SESSION['id']==null){
    header('location:Allfunctions.php');
}

?>
<style>
    table {
        background: linear-gradient(to right, #ffefba, #ffffff);
        border-collapse: collapse;
        width: 100%;
    }

    tr,
    td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    tr:hover {
        background-color: #f5f5f5;
    }
</style>

<form action="" method="post">
    <input type="text" name="search" placeholder="search">
    <input type="submit" name="submit" value="search">
    <td><a href="Allfunctions.php">Main Dashboard</a></td>
    <?php
$localhost="localhost";
$user="root";
$pass="";
$dbname="student";
$conn = mysqli_connect($localhost,$user,$pass,$dbname);
if(isset($_POST['submit'])){
    $ser=$_POST['search'];
 
    $sql="SELECT * FROM information where fullname LIKE '%$ser%' or id LIKE '%$ser%'";
}else{
   $sql="SELECT * FROM information"; 
}
//$sql="SELECT * FROM information";
$result = mysqli_query($conn,$sql);

   
?>
</form>
<table>
    <tr>
        <td>Id</td>
        <td>Name</td>
        <td>Email</td>
        <td>Age</td>
        <td>Contact</td>
        <td>Gender</td>
        <td>Image</td>
        <th>UPDATE</th>
        <th>DELETE</th>
        <th>LOGOUT</th>

    </tr>
    <!--  <tr>
        <?php
       //echo" <td> {$rows['id']}</td> <td>{$rows['fullname']} </td>";
   
   //} 
//}
       ?>
    </tr> -->
    <?php
    include 'connection.php';
    if(mysqli_num_rows($result)>0){
   while($rows=mysqli_fetch_array($result)){
    //  echo $rows['id'] ."<br>" . $rows['fullname'];
  $id = $rows['id'];
  $name = $rows['fullname'];
  $email = $rows['email'];
  $age = $rows['age'];
  $contact = $rows['contact'];
  $gender = $rows['gender'];
  $image = $rows['image'];
    ?>
    <tr>
        <td><?php echo $id; ?></td>
        <td><?php echo $name; ?></td>
        <td><?php echo $email; ?></td>
        <td><?php echo $age; ?></td>
        <td><?php echo $contact; ?></td>
        <td><?php echo $gender; ?></td>
        <td><?php echo $image; ?></td>
        <td><a href="updateform.php?id=<?php echo $id; ?>">update</a></td>
        <td><a href="delete.php?id=<?php echo $id; ?>">Delete</a></td>
        <td><a href="logout.php">logout</a></td>
    </tr>
    <?php }} ?>
</table>