<?php
include 'connection.php';
$sql='select * from information';
$query=mysqli_query($conn,$sql);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update</title>
</head>
<body>
    
</body>
</html>